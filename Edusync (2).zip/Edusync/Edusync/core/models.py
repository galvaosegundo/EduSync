# core/models.py
from django.db import models

# Manager personalizado para o Soft Delete
class SoftDeleteManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(is_deleted=False)

# Modelo base abstrato
class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_deleted = models.BooleanField(default=False)

    # Managers
    objects = SoftDeleteManager()  # Filtra os deletados
    all_objects = models.Manager() # Retorna todos, inclusive os deletados

    class Meta:
        abstract = True # Impede que o Django crie uma tabela para este modelo
        ordering = ['-created_at']

    def soft_delete(self):
        self.is_deleted = True
        self.save()

    def restore(self):
        self.is_deleted = False
        self.save()

