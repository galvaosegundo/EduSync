# escola/views.py

from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Aluno, Professor
from .serializers import AlunoSerializer, ProfessorSerializer

class ProfessorViewSet(viewsets.ModelViewSet):
    """
    Endpoint da API para ver ou editar professores.
    """
    permission_classes = [IsAuthenticated]
    queryset = Professor.objects.all()
    serializer_class = ProfessorSerializer

class AlunoViewSet(viewsets.ModelViewSet):
    """
    Endpoint da API para ver ou editar alunos.
    """
    permission_classes = [IsAuthenticated]
    queryset = Aluno.objects.all()
    serializer_class = AlunoSerializer