from django.db import models
from core.models import BaseModel # 1. Verifique se esta linha existe

class Professor(BaseModel): # 2. Garanta que (BaseModel) está aqui
    nome = models.CharField(max_length=150)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.nome

class Aluno(BaseModel): # 3. Garanta que (BaseModel) está aqui também
    nome = models.CharField(max_length=150)
    matricula = models.CharField(max_length=20, unique=True)
    data_nascimento = models.DateField()

    def __str__(self):
        return self.nome