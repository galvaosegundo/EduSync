# escola/urls.py
from rest_framework.routers import DefaultRouter
from .views import ProfessorViewSet, AlunoViewSet

# O router cria as rotas GET, POST, PUT, DELETE, etc. automaticamente
router = DefaultRouter()
router.register(r'professores', ProfessorViewSet)
router.register(r'alunos', AlunoViewSet)

urlpatterns = router.urls